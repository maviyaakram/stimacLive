export const PRIMARY_BACKGROUND_COLOR = '#f6f6f6';
export const SECONDARY_BACKGROUND_COLOR = '#0077b6';
export const FOREGROUND_COLOR = '#023047';
export const primaryColor = '#1a936f'